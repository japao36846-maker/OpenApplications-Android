package app.openapplications.mobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val dashboardUrl = "https://openapplication.camposcloud.app/"
    private lateinit var root: LinearLayout
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 14)
        window.navigationBarColor = Color.rgb(12, 12, 14)
        showWelcome()
    }

    private fun showWelcome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(30), dp(28), dp(30))
            setBackgroundColor(Color.rgb(12, 12, 14))
        }
        val brand = TextView(this).apply {
            text = "OPEN\nAPPLICATIONS"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = .08f
        }
        val mark = TextView(this).apply {
            text = "OA"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(210, 35, 48))
            val p = dp(16)
            setPadding(p, p, p, p)
        }
        val headline = TextView(this).apply {
            text = "Sua operação,\nna palma da mão."
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(10))
        }
        val subtitle = TextView(this).apply {
            text = "Gerencie seus bots, acompanhe resultados e acesse as ferramentas da Open Applications em uma experiência feita para celular."
            textSize = 15f
            setTextColor(Color.rgb(180, 180, 187))
            gravity = Gravity.CENTER
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        val features = TextView(this).apply {
            text = "•  Painel adaptado para celular\n•  Acesso seguro à sua conta\n•  Bots, vendas e Open Wallet"
            textSize = 14f
            setTextColor(Color.rgb(225, 225, 229))
            setLineSpacing(dp(9).toFloat(), 1f)
            setPadding(dp(10), dp(24), dp(10), dp(28))
        }
        val login = Button(this).apply {
            text = "Entrar na minha conta"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(210, 35, 48)))
            setOnClickListener { openDashboard() }
        }
        val note = TextView(this).apply {
            text = "Aplicativo oficial • Open Applications"
            textSize = 12f
            setTextColor(Color.rgb(125, 125, 133))
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        }
        root.addView(mark, LinearLayout.LayoutParams(dp(64), dp(64)).apply { bottomMargin = dp(18) })
        root.addView(brand)
        root.addView(headline)
        root.addView(subtitle)
        root.addView(features)
        root.addView(login, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(note)
        setContentView(root)
    }

    private fun openDashboard() {
        val wv = WebView(this)
        webView = wv
        wv.setBackgroundColor(Color.rgb(12, 12, 14))
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.databaseEnabled = true
        wv.settings.javaScriptCanOpenWindowsAutomatically = true
        wv.settings.setSupportMultipleWindows(false)
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = uri.host ?: return false
                if (host == "openapplication.camposcloud.app" || host.endsWith(".camposcloud.app")) return false
                if (uri.scheme == "https" || uri.scheme == "http") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }
                return false
            }
        }
        setContentView(wv)
        wv.loadUrl(dashboardUrl)
    }

    override fun onBackPressed() {
        val wv = webView
        if (wv != null && wv.canGoBack()) wv.goBack()
        else if (wv != null) {
            webView = null
            showWelcome()
        } else super.onBackPressed()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
