# Open Applications — Android

Projeto Android nativo (Kotlin), com tela inicial própria e a dashboard aberta dentro do aplicativo. Não é PWA.

## Gerar APK pelo GitHub Actions (sem instalar Android Studio)
1. Crie um repositório privado no GitHub.
2. Envie **o conteúdo desta pasta** para a raiz do repositório (não envie o ZIP como um único arquivo).
3. Abra a aba **Actions** e execute **Build Android APK** usando **Run workflow**. Também executa quando os arquivos do app mudam.
4. Quando terminar, abra a execução concluída e baixe o artefato `OpenApplications-debug-apk`. Dentro dele estará `app-debug.apk`.
5. Baixe o APK no Android, abra o arquivo e permita instalação dessa fonte quando o Android solicitar.

## Gerar localmente
Abra a pasta no Android Studio, sincronize o Gradle e escolha **Build > Build APK(s)**. O arquivo de teste normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Endereço da dashboard
O app abre `https://openapplication.camposcloud.app/`. Para alterar, edite `dashboardUrl` em `app/src/main/java/app/openapplications/mobile/MainActivity.kt`.

## Antes de distribuir
- O login e as funcionalidades continuam dependendo do servidor da dashboard.
- Teste autenticação Discord/OAuth, sessão, pagamentos, downloads e links externos em um aparelho real.
- O APK debug é adequado para testes; para distribuição ampla, gere APK assinado em **Build > Generate Signed Bundle / APK** e guarde a chave de assinatura em segurança.
- Não inclua chaves de API, tokens ou segredos no APK.
